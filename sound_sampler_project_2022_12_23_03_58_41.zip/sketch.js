/*
sound sampler
by elias leon
december 2022

Low Poly Lion Face by GDJ 
https://openclipart.org/detail/246150/low-poly-lion-face
shared under CC license 1 public domain" https://creativecommons.org/publicdomain/zero/1.0/ </a>

wave icon by uroesch 
https://openclipart.org/detail/216513/wave-icon

Black Bird In Black Moon
by liftarn https://openclipart.org/detail/320500/black-bird-in-black-moon

Futuristic City Skyline
by GDJ https://openclipart.org/detail/262179/futuristic-city-skyline

lion roar by Podcapocalipsis
https://freesound.org/people/Podcapocalipsis/sounds/559600/
This work is licensed under the Creative Commons 0 License.

oceanwavesounds.wav by Ryryk54312 https://freesound.org/people/Ryryk54312/sounds/587040/
This work is licensed under the Creative Commons 0 License.

Glasgow City Ambiences » Crowd Noise Light 2.wav by iamazerrad
https://freesound.org/people/iamazerrad/sounds/274352/


*/

var lionSound;
var waveSound;
var citySound;
var birdSound;
var lionColorImage;
var waveImage;
var birdImage;
var cityImage;

function preload(){
 lionSound = loadSound('lion.mp3');
 waveSound = loadSound('wave.wav'); 
 citySound = loadSound('city.wav'); 
 birdSound = loadSound('birds.wav'); 
 lionColorImage = loadImage('lioncolor.svg');
 waveImage = loadImage('wave.png');
 birdImage = loadImage('bird.png');
 cityImage = loadImage('city.png'); 
}

function setup() {
  createCanvas(600, 400);
}

function keyPressed(){
  //play a sound
  if (keyCode === 65) { //a
   if (lionSound.isPlaying()) {
      lionSound.stop();
    } else {
      lionSound.play();
    }
  }
}

function draw() {
  background(220);
  text('Press a, b, c, and d to explore the sound', 180, 200);
  textSize(18);
  fill("white");
  
  if (keyIsPressed) {
    if (keyCode === 65) { //a
    background('red');
    lionSound.play();  
    }
    if (keyCode === 66) { //b
    background('lightblue');  
    waveSound.play(); 
    }
    if (keyCode === 67) { //c
    background('purple');  
    citySound.play(); 
    }
    
     if (keyCode === 68) { //d
    background('yellow');  
    birdSound.play(); 
    }     
    
  }

  // draw if lion sound is playing
   if (lionSound.isPlaying()) {
     image(lionColorImage, 40, 40);
   } 
  
    if (waveSound.isPlaying()) {
     image(waveImage, 40+100, 40);
   } 
  
   if (citySound.isPlaying()) {
     image(cityImage, 40+200, 40);
   } 
  
    if (birdSound.isPlaying()) {
     image(birdImage, 40+300, 40);
      
    }
  
}